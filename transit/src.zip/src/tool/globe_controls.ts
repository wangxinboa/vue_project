import {
	Vector2,
	Vector3,
	Quaternion,
	// BoxGeometry,
	// MeshBasicMaterial,
	// Mesh
} from '../../libs/three.module';
import Camera from '../core/camera';
import Earth from '../earth/earth';


const _mouseButtons = {
	LEFT: 0,
	MIDDLE: 1,
	RIGHT: 2
}

const STATE = {
	NONE: -1,
	PAN: 0,
	ZOOM: 1,
	ROTATE: 2,
}


export default class GlobeControls{

	public dispose: Function;

	constructor(camera: Camera, canvas: HTMLCanvasElement, earth: Earth){
		console.log('GlobeControls');

		let
			hasDown = false,
			isMouse,

			state = STATE.NONE,

			// panStart: Vector2 = new Vector2(),
			panPoint: Vector3,
			
			rotateStart: Vector2 = new Vector2(),
			rotateEnd = new Vector2(),

			verticalAxis =  new Vector3(),

			verticalAngleStart = 0,
			verticalAngleDelta,

			rotatePoint: Vector3,

			zoomPoint: Vector3,

			_quaternion: Quaternion = new Quaternion(),
			cameraPsotion: Vector3 = new Vector3().copy(camera.position);


		function update(){

			camera.applyQuaternion(_quaternion);
			camera.position.copy(cameraPsotion);

			earth.update(camera);
		}

		function setMouseVector2(event: any, v: Vector2){
			v.x = ( event.offsetX / canvas.offsetWidth ) * 2 - 1;
			v.y = - ( event.offsetY / canvas.offsetHeight ) * 2 + 1;
		}


		// Pan 操作

		function handleMouseDownPan( event: any ){
			panPoint = earth.getIntersection(event, camera);
		}

		function handleMouseMovePan( event: any ){
			if( panPoint ){
				let
					intersection = earth.getIntersection(event, camera),
					earthCenter = earth.getCenter();

				if( intersection ){
					let
						sV = panPoint.clone().sub(earthCenter),
						eV = intersection.clone().sub(earthCenter),
						angle = sV.angleTo(eV),
						axis = sV.clone().cross(eV).normalize(),

						v = cameraPsotion.clone().sub(earthCenter);

					_quaternion.setFromAxisAngle(axis, -angle);

					cameraPsotion.sub(v);
					v.applyQuaternion(_quaternion);
					cameraPsotion.add(v);

					// panPoint.copy(intersection);
					update();
				}else{
					panPoint = void 0;
				}
			}
		}

		// Zoom 操作

		function handleMouseDownZoom( event: any ){
			
		}

		function handleMouseMoveZoom( event: any ){

		}

		// Rotate 操作

		function handleMouseDownRotate( event: any ){
			setMouseVector2(event, rotateStart);
			rotatePoint = earth.getIntersection(event, camera);
			verticalAxis.copy(rotatePoint).sub(earth.getCenter()).normalize();
		}

		function handleMouseMoveRotate( event: any ){

			if( rotatePoint ){
				setMouseVector2(event, rotateEnd);
				verticalAngleDelta = ( rotateEnd.x - rotateStart.x ) * Math.PI / 2;

				let
					v = cameraPsotion.clone().sub(rotatePoint);

				_quaternion.setFromAxisAngle( verticalAxis, verticalAngleStart - verticalAngleDelta );
				verticalAngleStart = verticalAngleDelta;

				cameraPsotion.sub( v );
				v.applyQuaternion(_quaternion);
				cameraPsotion.add( v );

				verticalAxis.applyQuaternion(_quaternion);



				update();
			}

			// _quaternion.setFromAxisAngle( xAxis, nowXAngle - rX );


		}


		// canvas 添加事件

		canvas.addEventListener( 'contextmenu', onContextMenu );
		function onContextMenu( event: any ) {
			event.preventDefault();
		}

		// pointer 相关
		canvas.addEventListener( 'pointerdown', onPointerDown );
		function onPointerDown( event: any ) {

			if ( !hasDown ){
				hasDown = true;

				canvas.addEventListener( 'pointermove', onPointerMove );
				canvas.addEventListener( 'pointerup', onPointerUp );

			}

			if ( event.pointerType === 'touch' ) {
				isMouse = false;
				alert('暂不支持移动端');
			}else{
				isMouse = true;
				canvas.addEventListener( 'mouseleave', onMouseLeave );
				onMouseDown(event);
			}
		}

		function onPointerMove( event: any ){

			if ( event.pointerType === 'touch' ) {
				alert('暂不支持移动端');
			} else {
				onMouseMove( event );
			}
		}

		function onPointerUp( event: any ){
			endDown();
		}

		function endDown(){
			if( hasDown ){
				hasDown = false;
				canvas.removeEventListener( 'pointermove', onPointerMove );
				canvas.removeEventListener( 'pointerup', onPointerUp );
				if( isMouse ){
					canvas.removeEventListener( 'mouseleave', onMouseLeave );
				}
			}
			state = STATE.NONE;
		}

		// pc 端
		function onMouseDown( event: any ){
			if(state !== STATE.NONE){
				console.log('已经在变化了, 保持之前的变化不作改变');
				return;
			}

			switch ( event.button ) {
				case _mouseButtons.LEFT: 
					console.log('左键');
					handleMouseDownPan( event );
					state = STATE.PAN;
					break;
				case _mouseButtons.MIDDLE: 
					console.log('中间');
					handleMouseDownZoom( event );
					state = STATE.ZOOM;
					break;
				case _mouseButtons.RIGHT: 
					console.log('右键');
					handleMouseDownRotate( event );
					state = STATE.ROTATE;
					break;
			}
		}

		function onMouseMove( event: any ) {

			switch ( state ) {
				case STATE.PAN:
					handleMouseMovePan( event );
					break;
				case STATE.ZOOM:
					handleMouseMoveZoom( event );
					break;
				case STATE.ROTATE:
					handleMouseMoveRotate( event );
					break;
			}
		}

		function onMouseLeave( event: any ) {
			endDown();
		}



		this.dispose = function () {
			canvas.removeEventListener( 'contextmenu', onContextMenu );
			canvas.removeEventListener( 'pointerdown', onPointerDown );

			endDown();
		}

	}

}