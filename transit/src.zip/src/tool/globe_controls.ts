import {
	Vector2,
	Vector3,
	BoxGeometry,
	MeshBasicMaterial,
	Mesh
} from '../../libs/three.module';
import Camera from '../core/camera';
import Earth from '../earth/earth';


const _mouseButtons = {
	LEFT: 0,
	MIDDLE: 1,
	RIGHT: 2
}

const STATE = {
	NONE: -1,
	PAN: 0,
	ZOOM: 1,
	ROTATE: 2,
}


export default class GlobeControls{

	public dispose: Function;

	constructor(camera: Camera, canvas: HTMLCanvasElement, earth: Earth){
		console.log('GlobeControls');

		let
			hasDown = false,
			isMouse,

			state = null,

			// panStart: Vector2 = new Vector2(),
			panPoint: Vector3,
			
			// rotateStart: Vector2 = new Vector2(),
			rotatePoint: Vector3,

			zoomPoint: Vector3;


		function update(){

			earth.update(camera);
		}



		function handleMouseDownPan( event: any ){
			// setMousePoint(event, panStart);
			// panPoint = terrain.getEllipseIntersection();
		}

		function handleMouseMovePan( event: any ){

		}

		function handleMouseDownZoom( event: any ){
			
		}

		function handleMouseMoveZoom( event: any ){

		}

		function handleMouseDownRotate( event: any ){
			
		}

		function handleMouseMoveRotate( event: any ){

		}


		// canvas 添加时间

		canvas.addEventListener( 'contextmenu', onContextMenu );
		function onContextMenu( event: any ) {
			event.preventDefault();
		}

		// pointer 相关
		canvas.addEventListener( 'pointerdown', onPointerDown );
		function onPointerDown( event: any ) {

			if ( !hasDown ){
				hasDown = true;

				canvas.addEventListener( 'pointermove', onPointerMove );
				canvas.addEventListener( 'pointerup', onPointerUp );

			}

			if ( event.pointerType === 'touch' ) {
				isMouse = false;
				alert('暂不支持移动端');
			}else{
				isMouse = true;
				canvas.addEventListener( 'mouseleave', onMouseLeave );
				onMouseDown(event);
			}
		}

		function onPointerMove( event: any ){

			if ( event.pointerType === 'touch' ) {
				alert('暂不支持移动端');
			} else {
				onMouseMove( event );
			}
		}

		function onPointerUp( event: any ){
			endDown();
		}

		function endDown(){
			if( hasDown ){
				hasDown = false;
				canvas.removeEventListener( 'pointermove', onPointerMove );
				canvas.removeEventListener( 'pointerup', onPointerUp );
				if( isMouse ){
					canvas.removeEventListener( 'mouseleave', onMouseLeave );
				}
			}
		}

		// pc 端
		function onMouseDown( event: any ){

			switch ( event.button ) {
				case _mouseButtons.LEFT: 
					// console.log('左键');
					handleMouseDownPan( event );
					state = STATE.PAN;
					break;
				case _mouseButtons.MIDDLE: 
					// console.log('中间');
					handleMouseDownZoom( event );
					state = STATE.ZOOM;
					break;
				case _mouseButtons.RIGHT: 
					// console.log('右键');
					handleMouseDownRotate( event );
					state = STATE.ROTATE;
					break;
			}
		}

		function onMouseMove( event: any ) {

			switch ( state ) {
				case STATE.PAN:
					handleMouseMovePan( event );
					break;
				case STATE.ZOOM:
					handleMouseMoveZoom( event );
					break;
				case STATE.ROTATE:
					handleMouseMoveRotate( event );
					break;
			}
		}

		function onMouseLeave( event: any ) {
			endDown();
		}



		this.dispose = function () {
			canvas.removeEventListener( 'contextmenu', onContextMenu );
			canvas.removeEventListener( 'pointerdown', onPointerDown );

			endDown();
		}

	}

}