import {
	Scene,
	Matrix4,
	Vector2,
	Vector3,
	Group
} from '../../libs/three.module';

import { isEmpty, isNumber, isInstance } from '../core/check_value';
import developerError from '../core/developer_error';

import Terrain from './terrain/terrain';
import Tile from './tile/tile';
import earthOptions, { createDefaultEarthOption } from './types/earth_options';
import Layer from './layer/layer';
import Provider from './layer/provider/provider';
import Cartograph from './coordinates/cartograph';
import Camera from '../core/camera';


export default class Earth{

	private canvas: HTMLCanvasElement;
	private scene: Scene;

	private minLevel: number;
	private maxLevel: number;

	private terrain: Terrain;

	private rootTiles: Array<Tile>;
	private baseTiles: Array<Tile> = [];

	public layer: Layer = new Layer();

	constructor( options: earthOptions ){

		let defaultEarthOption = createDefaultEarthOption();

		if( isEmpty(options) ){
			options = defaultEarthOption;
		}

		if( isNumber(options.minLevel) ){
			this.minLevel = options.minLevel;
		}else{
			this.minLevel = defaultEarthOption.minLevel;
		}

		if( isNumber(options.maxLevel) ){
			this.maxLevel = options.maxLevel;
		}else{
			this.maxLevel = defaultEarthOption.maxLevel;
		}

		if( this.maxLevel < this.minLevel ){
			developerError('瓦片最低层级比最高层级大');
		}

		if( isInstance(options.terrain, Terrain) ){
			this.terrain = options.terrain;
		}else{
			this.terrain = defaultEarthOption.terrain;
		}

		this.rootTiles = this.terrain.getRootTiles(this.layer);

		if( isInstance(options.provider, Provider) ){
			this.layer.setProvider(options.provider);
		}else{
			this.layer.setProvider(defaultEarthOption.provider);
		}

		if( isInstance(options.origin, Cartograph) ){
			this.setOrigin( options.origin );
		}else{
			this.setOrigin( defaultEarthOption.origin );
		}

		this.setBaseTiles();
	}

	public getTerrain(): Terrain{
		return this.terrain;
	}

	public mount(canvas: HTMLCanvasElement,scene: Scene): Earth{
		this.canvas = canvas;
		this.scene = scene;
		scene.add(this.terrain.tileGroup);
		return this;
	}

	public getScene(): Scene{
		return this.scene;
	}

	public setOrigin(cartograph: Cartograph): Earth{
		this.terrain.setOrigin(cartograph);
		return this;
	}

	private traverse(callback: Function): Earth{

		this.rootTiles.forEach((tile)=>{
			tile.traverse(callback);
		});

		return this;
	}

	public setMinLevel(minLevel: number): Earth{
		this.minLevel = minLevel;
		this.setBaseTiles();
		return this;
	}

	private setBaseTiles(){

		for( let i = this.baseTiles.length - 1; i >=0; i-- ){
			let tile = this.baseTiles[i];
			tile.cancelBase();
			this.baseTiles.pop();
		}

		this.traverse((tile: Tile)=>{
			if( tile.level <= this.minLevel ){
				if( tile.level === this.minLevel ){
					tile.confirmBase();
					this.baseTiles.push(tile);
				}
				return true;
			}
			return false;
		});
	}

	public getIntersection(event: any, camera: Camera): Vector3{
		let
			mouse = new Vector2(
				v.x =( event.offsetX / canvas.offsetWidth ) * 2 - 1;
				v.y =	- ( event.offsetY / canvas.offsetHeight ) * 2 + 1
			)
		return 
	}


	public update(camera: Camera): Earth{

		return this;
	}


}