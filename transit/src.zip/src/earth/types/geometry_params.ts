
type geometryParams = {
	vertices: Array<number>,
	uvs: Array<number>,
	normals: Array<number>,
	indices: Array<number>
}

export default geometryParams;