import {
	Texture
} from '../../../libs/three.module';
import Tile from '../tile/tile';
import Provider from './provider/provider';
import developerError from '../../core/developer_error';

export default class Layer{
	
	private providers: Array<Provider> = [];
	private waitStack: Array<Tile> = [];

	private isLoading: boolean = false;

	private nowLoadingTile: Tile;
	private nowLoadingProviderIndex: number;
	// constructor(){

	// }

	public addProvider(provider: Provider): Layer{
		this.providers.push(provider);
		return this;
	}

	public setProvider(provider: Provider): Layer{
		if( this.providers.length === 0 ){
			this.providers.push(provider);
		}else{
			this.providers = [provider];
		}
		return this;
	}

	public getProvidersLength(): number{
		return this.providers.length;
	}

	public clearTiles(): Layer{

		this.isLoading = false;
		for( let i = this.waitStack.length - 1; i >=0; i-- ){
			let tile = this.waitStack[i];
			tile.cancelLoad();
			this.waitStack.pop();
		}
		return this;
	}

	public loadTileMap(tile: Tile): Layer{
		if( this.providers.length > 0 ){
			this.waitStack.push(tile);
			if( !this.isLoading ){
				this.requestTileMap();
				this.isLoading = true;
			}
		}else{
			developerError('没有添加地图图层');
		}
		return this;
	}

	private requestTileMap(): Layer{
		this.nowLoadingTile = this.waitStack[this.waitStack.length - 1];
		this.nowLoadingProviderIndex = 0;

		this.nowLoadingTile.loadingMap();
		this.waitStack.pop();
		this.requestTileImage();

		// console.log('正在请求的瓦片', this.nowLoadingTile.order);
		return this;
	}

	private requestTileImage(): Layer{
		let 
				provider = this.providers[this.nowLoadingProviderIndex],
				tile = this.nowLoadingTile;

		if( tile.hasProviderImage(provider) ){
			this.requestNextTileImage();
		}else{
			let
					url = provider.getUrl(tile.column, tile.row, tile.level),
					img = new Image();

			img.crossOrigin = "anonymous";
			img.src = url;

			img.onload = () => {
				tile.setImage(provider, img);
				this.requestNextTileImage();
			}
			img.onerror = () => {
				// console.error(`'图片加载失败,瓦片序列 ${tile.column} ${tile.row} ${tile.level}`);
				// tile.setImage();
			}
		}
		return this;
	}

	private requestNextTileImage(): Layer{
		if( this.nowLoadingProviderIndex === this.providers.length - 1 ){
			// console.log('加载图片', this.nowLoadingTile.order);
			this.nowLoadingTile.loadedMap();
			if( this.waitStack.length === 0 ){
				// console.log('全部图片加载完成');
				this.isLoading = false;
			}else{
				// console.log('加载下一张图片');
				this.requestTileMap();
			}
		}else{
			this.nowLoadingProviderIndex ++;
			this.requestTileImage();
		}
		return this;
	}

}



