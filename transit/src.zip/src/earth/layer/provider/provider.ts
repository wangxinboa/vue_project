


export default abstract class Provider{

	public abstract getUrl(column: number, raw: number, level: number): string;

	// public abstract onLoad(callback: function): Provider;

	// public abstract onError(callback: function): Provider;
}
