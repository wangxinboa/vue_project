

export default class Cartograph{

	longitude;
	latitude;
	height;

	constructor(longitude = 0, latitude = 0, height = 0){
		this.longitude = longitude;
		this.latitude = latitude;
		this.height = height;
	}
}