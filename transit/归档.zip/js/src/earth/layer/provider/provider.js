

export default class Provider{

	getUrl(column, raw, level){
	}
}