
export default function developerError(error){
	throw new Error(error)
}