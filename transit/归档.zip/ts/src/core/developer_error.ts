

export default function developerError(error: string){
	throw new Error(error)
}