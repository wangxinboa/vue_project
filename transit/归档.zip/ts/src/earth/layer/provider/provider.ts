


export default abstract class Provider{

	public abstract getUrl(column: number, raw: number, level: number): string;
}
